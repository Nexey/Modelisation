# Modelisation
Projet de L3 de modélisation.

Participants du projet :
- DAVIES Liam
- LANNUEL Charlotte
- SCHWAB Lucas


Installation du projet :
Il est important de respecter la hiérarchie des dossiers
afin d'exécuter l'application via Visual Studio ou tout 
autre compilateur.

Il n'est toutefois pas nécessaire de placer le .exe dans
un dossier particulier pour l'exécuter, il suffit simplement
de glisser un fichier .gpr sur le .exe pour le lancer.